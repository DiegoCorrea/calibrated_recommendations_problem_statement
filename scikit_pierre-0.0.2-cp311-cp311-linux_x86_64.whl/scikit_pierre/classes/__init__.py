"""
This file init classes/genres module
"""
