"""
This file init the distribution module.
"""
