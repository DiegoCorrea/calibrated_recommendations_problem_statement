"""
This file is to init the unit test on the measure module.
"""
