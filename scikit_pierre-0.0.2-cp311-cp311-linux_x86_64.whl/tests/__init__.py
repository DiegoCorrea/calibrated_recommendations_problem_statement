"""
This file is to init the test module.
"""
